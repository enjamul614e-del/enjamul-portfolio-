
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.project-image img').forEach(image => {
    const showFallback = () => {
      image.hidden = true;
      image.parentElement.classList.add('project-image--fallback');
    };

    image.addEventListener('error', showFallback, { once: true });
    if (image.complete && image.naturalWidth === 0) {
      showFallback();
    }
  });

  // Smooth scrolling for navigation links
  const navLinks = document.querySelectorAll('.nav-links a[href^="#"]');
  navLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const targetId = e.currentTarget.getAttribute('href');
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        const headerOffset = document.getElementById('header').offsetHeight;
        const elementPosition = targetElement.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

        window.scrollTo({
          top: offsetPosition,
          behavior: 'smooth'
        });

        // Close mobile menu if open
        if (mobileNavLinks.classList.contains('active')) {
            mobileNavLinks.classList.remove('active');
            menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
            menuToggle.setAttribute('aria-expanded', 'false');
        }
      }
    });
  });

  // Active navigation link highlighting on scroll
  const sections = document.querySelectorAll('main section[id]');
  function changeLinkState() {
    let index = sections.length;
    const headerHeight = document.getElementById('header').offsetHeight;

    while(--index && window.scrollY + headerHeight + 50 < sections[index].offsetTop) {}
    
    navLinks.forEach((link) => link.classList.remove('active'));
    // Check if the corresponding link exists before adding 'active' class
    const activeLink = document.querySelector(`.nav-links a[href="#${sections[index].id}"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }
  }
  changeLinkState(); // Initial check
  window.addEventListener('scroll', changeLinkState);


  // Mobile menu toggle
  const menuToggle = document.getElementById('menuToggle');
  const mobileNavLinks = document.querySelector('.nav-links');

  menuToggle.addEventListener('click', () => {
    mobileNavLinks.classList.toggle('active');
    const isExpanded = mobileNavLinks.classList.contains('active');
    menuToggle.setAttribute('aria-expanded', isExpanded.toString());
    if (isExpanded) {
        menuToggle.innerHTML = '<i class="fas fa-times"></i>'; // Change to close icon
    } else {
        menuToggle.innerHTML = '<i class="fas fa-bars"></i>'; // Change back to menu icon
    }
  });


  // Header scroll effect
  const header = document.getElementById('header');
  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      header.classList.add('header-scrolled');
    } else {
      header.classList.remove('header-scrolled');
    }
  });

  // Dynamic year in footer
  const currentYearSpan = document.getElementById('currentYear');
  if (currentYearSpan) {
    currentYearSpan.textContent = new Date().getFullYear().toString();
  }

  console.log("Portfolio Interactive Script Loaded");
});
