export function handleHealthRoute(request, response) {
  const pathname = new URL(request.url, 'http://localhost').pathname;

  if (request.method !== 'GET' || pathname !== '/api/health') {
    return false;
  }

  response.writeHead(200, { 'Content-Type': 'application/json' });
  response.end(JSON.stringify({ status: 'ok' }));
  return true;
}
