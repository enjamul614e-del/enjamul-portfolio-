import { createServer } from 'node:http';
import { handleHealthRoute } from './routes/health.js';

const port = Number(process.env.PORT ?? 3001);

const server = createServer((request, response) => {
  if (handleHealthRoute(request, response)) {
    return;
  }

  response.writeHead(404, { 'Content-Type': 'application/json' });
  response.end(JSON.stringify({ error: 'Not found' }));
});

server.listen(port, '127.0.0.1', () => {
  console.log(`Backend API listening at http://localhost:${port}`);
});
